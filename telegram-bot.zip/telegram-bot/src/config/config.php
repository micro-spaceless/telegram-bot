<?php

    return [
        'token'  => 'YOUR-BOT-TOKEN',
        'chatId' => 'YOUR-CHAT-ID',
    ];
